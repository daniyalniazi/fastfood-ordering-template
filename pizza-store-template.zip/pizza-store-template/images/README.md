# Images

Put your own photos and logo files in this folder.

Then point to them by path:

- Logo, in `config.js`: `logo: 'images/logo.png'`
- Product photo, in `menu.js`: `image: 'images/margherita.png'`
- Deal poster, in `menu.js`: `banner: 'images/family-deal-poster.jpg'`

Tips:

- File names are case-sensitive once the site is online. `Logo.png` and `logo.png` are different files.
- Use lowercase names with dashes and no spaces, like `bbq-chicken.png`.
- Food photos look best as PNG cut-outs with a transparent background, about 800 px wide.
- Keep each file under about 300 KB so the site loads fast on phones.

You can delete this file once you've added your own images.
